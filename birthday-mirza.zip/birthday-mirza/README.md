# Chapter XVIII — Ahmad Mirza Maulana

Website ucapan ulang tahun ke-18: sebuah halaman statis (HTML + CSS + JS) tanpa build tools.

## Struktur

```
.
├── index.html
├── assets/
│   ├── photo1.jpg … photo4.jpg
│   └── birthday-music.mp3
├── .nojekyll
├── .gitignore
└── README.md
```

## Jalankan lokal

Buka `index.html` langsung di browser, atau jalankan server sederhana:

```bash
python3 -m http.server 8000
# lalu buka http://localhost:8000
```

## Deploy ke GitHub Pages

1. Push repo ini ke GitHub.
2. Buka **Settings → Pages**.
3. Pada **Build and deployment**, pilih **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. Tunggu beberapa menit, situs tersedia di `https://<username>.github.io/<nama-repo>/`.

## Ganti foto / musik

Timpa file di folder `assets/` dengan nama yang sama (`photo1.jpg` – `photo4.jpg`, `birthday-music.mp3`). Caption foto diubah langsung di `index.html`.
